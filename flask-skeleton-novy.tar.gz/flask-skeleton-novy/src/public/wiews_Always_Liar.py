"""
Logic for dashboard related routes
"""
from flask import Blueprint, render_template
from .forms import LogUserForm, secti,masoform,formKformular, advancedform
from ..data.database import db
from ..data.models import LogUser

from .views import blueprint
@blueprint.route("/vypis_i", methods = ["GET"])
def vypis_i():
    pole=[[0,1], [2,3]]
    pole [0][1]=10 + 1
    return render_template("public/vypis_i.tmpl", data = pole)


@blueprint.route("/formularformular", methods=['GET', 'POST'])
def formular():
    form = formKformular()
    if form.validate_on_submit():
        data = 0
        return render_template("public/vypis_vysledku.tmpl", data=data)
    return render_template("public/formular.tmpl", form=form)

@blueprint.route("/advancedforms", methods=["GET", "POST"])
def advancedformformular():
    form=advancedform()
    if form.validate_on_submit():
        if form.oo.data == "1" and form.obrazec.data == "1" :
            return str(form.a.data*form.a.data)
        if form.oo.data == "1" and form.obrazec.data == "2" :
            return str(form.a.data*form.b.data)
        if form.oo.data == "1" and form.obrazec.data == "3" :
            return "vypoceet obsahu trojuhelnika"
        if form.oo.data == "2" and form.obrazec.data == "1" :
            return str(4*form.a.data)
        if form.oo.data == "2" and form.obrazec.data == "2" :
            return str(2*form.a.data+2*form.b.data)
        if form.oo.data == "2" and form.obrazec.data == "3" :
            return str(form.a.data+form.b.data+form.a.data)
    return render_template("public/advancedform.tmpl", form = form)


@blueprint.route("/simple_chart")
def chart():
    legend = 'Monthly Data'
    labels = ["January", "February", "March", "April", "May", "June", "July", "August"]
    values = [10, 9, 8, 7, 6, 4, 7, 8]
    return render_template('public/vystup_graf.tmpl', values=values, labels=labels, legend=legend)
